// artist song
var audio = new Audio('song/song.mp3');
audio.pause();

var isplaying = false;

$(".play-button").on("click", function()
{
    $(".play-button").toggleClass("pause-button");
      if(isplaying == false) {
        audio.play();
        audio.currentTime = 0;
        isplaying = true;
        
      }
     

      else {
        $(".pause-button").toggleClass(".play-button");
        audio.pause();
        isplaying = false;
        audio.currentTime = 0;

      }


});


//hamburger
$(".hamburger").on("click", function()
{
  $(".buttons").toggleClass("open-menu");
});


